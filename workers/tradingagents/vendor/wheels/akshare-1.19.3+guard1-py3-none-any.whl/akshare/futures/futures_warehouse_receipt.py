#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Date: 2025/7/1 16:30
Desc: 期货-仓单日报
上海期货交易所-仓单日报
https://tsite.shfe.com.cn/statements/dataview.html?paramid=dailystock
郑州商品交易所-交易数据-仓单日报
http://www.czce.com.cn/cn/jysj/cdrb/H770310index_1.htm
大连商品交易所-行情数据-统计数据-日统计-仓单日报
http://www.dce.com.cn/dalianshangpin/xqsj/tjsj26/rtj/cdrb/index.html
广州期货交易所-行情数据-仓单日报
http://www.gfex.com.cn/gfex/cdrb/hqsj_tjsj.shtml
"""

import re
from io import BytesIO, StringIO

import pandas as pd
import requests
from bs4 import BeautifulSoup

from akshare.exceptions import APIError


def futures_warehouse_receipt_czce(date: str = "20251103") -> dict:
    """
    郑州商品交易所-交易数据-仓单日报
    http://www.czce.com.cn/cn/jysj/cdrb/H770310index_1.htm
    :param date: 交易日，e.g., "20200702"
    :type date: str
    :return: 指定日期的仓单日报数据
    :rtype: dict
    """
    import urllib3

    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    if int(date) > 20251101:
        url = f"http://www.czce.com.cn/cn/DFSStaticFiles/Future/{date[:4]}/{date}/FutureDataWhsheet.xlsx"
    else:
        url = f"http://www.czce.com.cn/cn/DFSStaticFiles/Future/{date[:4]}/{date}/FutureDataWhsheet.xls"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/83.0.4103.116 Safari/537.36"
    }
    r = requests.get(url, verify=False, headers=headers)
    temp_df = pd.read_excel(BytesIO(r.content))
    index_list = temp_df[temp_df.iloc[:, 0].str.find("品种") == 0.0].index.to_list()
    index_list.append(len(temp_df))
    big_dict = {}
    for inner_index in range(len(index_list) - 1):
        inner_df = temp_df[index_list[inner_index] : index_list[inner_index + 1]]
        inner_key = re.findall(pattern=r"[a-zA-Z]+", string=inner_df.iloc[0, 0])[0]
        inner_df = inner_df.iloc[1:, :]
        inner_df.dropna(axis=0, how="all", inplace=True)
        inner_df.dropna(axis=1, how="all", inplace=True)
        inner_df.columns = inner_df.iloc[0, :].to_list()
        inner_df = inner_df.iloc[1:, :]
        inner_df.reset_index(inplace=True, drop=True)
        big_dict[inner_key] = inner_df
    return big_dict


def futures_warehouse_receipt_dce(date: str = "20251027") -> pd.DataFrame:
    """
    大连商品交易所-行情数据-统计数据-日统计-仓单日报
    http://www.dce.com.cn/dce/channel/list/187.html
    :param date: 交易日，e.g., "20200702"
    :type date: str
    :return: 指定日期的仓单日报数据
    :rtype: dict
    :raises APIError: 大连商品交易所网站启用瑞数反爬虫验证，拒绝程序请求时抛出
    """
    url = "http://www.dce.com.cn/dcereport/publicweb/dailystat/wbillWeeklyQuotes"
    payload = {
        "tradeDate": date,
        "varietyId": "all",
    }
    r = requests.post(url, json=payload, timeout=15)
    # 瑞数反爬虫对未通过浏览器验证的请求返回 412 挑战页，其 cookie 需每次请求前由 JS 重新生成
    if r.status_code == 412:
        raise APIError(
            "大连商品交易所网站启用了瑞数反爬虫验证，暂时无法通过程序获取仓单日报数据",
            status_code=r.status_code,
        )
    r.raise_for_status()
    data_json = r.json()
    temp_df = pd.DataFrame(data_json["data"]["entityList"])
    temp_df.rename(
        columns={
            "variety": "品种名称",
            "whAbbr": "仓库/分库",
            "deliveryAbbr": "可选提货地点/分库-数量",
            "lastWbillQty": "昨日仓单量（手）",
            "wbillQty": "今日仓单量（手）",
            "diff": "增减（手）",
            "varietyOrder": "品种代码",
        },
        inplace=True,
    )
    temp_df = temp_df[
        [
            "品种代码",
            "品种名称",
            "仓库/分库",
            "可选提货地点/分库-数量",
            "昨日仓单量（手）",
            "今日仓单量（手）",
            "增减（手）",
        ]
    ]
    return temp_df


def __futures_shfe_warehouse_receipt_html(date: str, headers: dict) -> dict:
    """
    上海期货交易所指定交割仓库期货仓单日报（2025-11-18 起的网页版）
    自 2025-11-18 起，交易所不再提供 dailydata/{date}dailystock.dat 数据文件（返回 404），
    改为按品种分表的网页 stockdata/dailystock_{date}/ZH/all.html；
    键为品种名称（如 "螺纹钢仓库"、"铜"、"铜(BC)"），
    值为包含 VARNAME, REGNAME, WHABBRNAME, WRTWGHTS, WRTCHANGE, ROWSTATUS 的 pandas.DataFrame，
    其中 ROWSTATUS 为 "0" 表示仓库，"1" 表示合计，"2" 表示总计
    :param date: 交易日，e.g., "20260924"
    :type date: str
    :param headers: 请求头
    :type headers: dict
    :return: 指定日期的仓单日报数据
    :rtype: dict
    """
    url = f"https://www.shfe.com.cn/data/tradedata/future/stockdata/dailystock_{date}/ZH/all.html"
    r = requests.get(url, headers=headers, timeout=15)
    r.raise_for_status()
    r.encoding = "utf-8"
    soup = BeautifulSoup(r.text, features="lxml")
    # 各表列顺序不一：多数为“地区、仓库/厂库”，部分厂库表为“厂库、地区”，原油为“地区、交割仓库、本日数量”
    column_map = {
        "地区": "REGNAME",
        "仓库": "WHABBRNAME",
        "厂库": "WHABBRNAME",
        "交割仓库": "WHABBRNAME",
        "期货": "WRTWGHTS",
        "本日数量": "WRTWGHTS",
        "增减": "WRTCHANGE",
    }
    big_dict = {}
    for table in soup.find_all("table"):
        header = [th.get_text(strip=True) for th in table.find_all("th")]
        title_tr = table.find("tr", class_="special_row_type")
        if not header or title_tr is None:
            continue
        columns = [column_map.get(item, item) for item in header]
        # "螺纹钢(仓库)" -> "螺纹钢仓库"；"铜(BC)" 保持不变
        var_name = (
            title_tr.td.get_text(strip=True)
            .replace("(仓库)", "仓库")
            .replace("(厂库)", "厂库")
        )
        spans = {}  # 记录被 rowspan 纵向合并的单元格：列序号映射到其文本与剩余行数
        rows = []
        for tr in table.find_all("tr"):
            if tr is title_tr or tr.find("th") is not None:
                continue
            cells = tr.find_all("td")
            row = []
            while len(row) < len(columns):
                col = len(row)
                if spans.get(col, ("", 0))[1] > 0:
                    text, remaining = spans[col]
                    spans[col] = (text, remaining - 1)
                    row.append(text)
                    continue
                if not cells:
                    break
                td = cells.pop(0)
                text = td.get_text(strip=True)
                rowspan = int(td.get("rowspan", 1))
                if rowspan > 1:
                    spans[col] = (text, rowspan - 1)
                # colspan 单元格的文本放在其覆盖的最后一列，如“总计”、黄金的“上期所指定交割金库”
                row.extend([""] * (int(td.get("colspan", 1)) - 1) + [text])
            if len(row) != len(columns):
                continue
            item = dict(zip(columns, row))
            if item["REGNAME"].endswith("总计") or item["WHABBRNAME"].endswith("总计"):
                item["WHABBRNAME"] = item["REGNAME"] + item["WHABBRNAME"]
                item["REGNAME"] = ""
                item["ROWSTATUS"] = "2"
            elif "合计" in (item["REGNAME"], item["WHABBRNAME"]):
                item["ROWSTATUS"] = "1"
            else:
                item["ROWSTATUS"] = "0"
            rows.append(item)
        if not rows:
            continue
        temp_df = pd.DataFrame(rows)
        temp_df["VARNAME"] = var_name
        temp_df = temp_df[
            ["VARNAME", "REGNAME", "WHABBRNAME", "WRTWGHTS", "WRTCHANGE", "ROWSTATUS"]
        ]
        temp_df["WRTWGHTS"] = pd.to_numeric(temp_df["WRTWGHTS"], errors="coerce")
        temp_df["WRTCHANGE"] = pd.to_numeric(temp_df["WRTCHANGE"], errors="coerce")
        big_dict[var_name] = temp_df
    return big_dict


def futures_shfe_warehouse_receipt(date: str = "20260924") -> dict:
    """
    上海期货交易所指定交割仓库期货仓单日报
    https://www.shfe.com.cn/reports/tradedata/dailyandweeklydata/
    :param date: 交易日，e.g., "20260924"
    :type date: str
    :return: 指定日期的仓单日报数据
    :rtype: dict
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/83.0.4103.116 Safari/537.36"
    }
    if date >= "20251118":
        return __futures_shfe_warehouse_receipt_html(date=date, headers=headers)
    url = (
        f"https://www.shfe.com.cn/data/tradedata/future/dailydata/{date}dailystock.dat"
    )
    if date >= "20140519":
        r = requests.get(url, headers=headers)
        data_json = r.json()
        temp_df = pd.DataFrame(data_json["o_cursor"])
        temp_df["VARNAME"] = temp_df["VARNAME"].str.split(r"$", expand=True).iloc[:, 0]
        temp_df["REGNAME"] = temp_df["REGNAME"].str.split(r"$", expand=True).iloc[:, 0]
        temp_df["WHABBRNAME"] = (
            temp_df["WHABBRNAME"].str.split(r"$", expand=True).iloc[:, 0]
        )
        big_dict = {}
        for item in set(temp_df["VARNAME"]):
            big_dict[item] = temp_df[temp_df["VARNAME"] == item]
    else:
        url = f"https://www.shfe.com.cn/data/tradedata/future/dailydata/{date}dailystock.html"
        r = requests.get(url, headers=headers)
        temp_df = pd.read_html(StringIO(r.text))[0]
        index_list = temp_df[
            temp_df.iloc[:, 3].str.contains("单位：") == 1
        ].index.to_list()
        big_dict = {}
        for inner_index in range(len(index_list)):
            temp_index_start = index_list[inner_index]
            if (inner_index + 1) >= len(index_list):
                if temp_df.iloc[-1, 0].startswith("注："):
                    temp_index_end = len(temp_df) - 1
                else:
                    temp_index_end = len(temp_df)
            else:
                temp_index_end = index_list[inner_index + 1]
            inner_df = temp_df[temp_index_start:temp_index_end]
            inner_df.reset_index(inplace=True, drop=True)
            inner_key = inner_df.iloc[0, 0]
            inner_df.columns = inner_df.iloc[1].to_list()
            inner_df = inner_df[2:]
            inner_df.reset_index(inplace=True, drop=True)
            big_dict[inner_key] = inner_df
    return big_dict


def futures_gfex_warehouse_receipt(date: str = "20240122") -> dict:
    """
    广州期货交易所-行情数据-仓单日报
    http://www.gfex.com.cn/gfex/cdrb/hqsj_tjsj.shtml
    :param date: 交易日，e.g., "20240122"
    :type date: str
    :return: 指定日期的仓单日报数据
    :rtype: dict
    """
    url = "http://www.gfex.com.cn/u/interfacesWebTdWbillWeeklyQuotes/loadList"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/83.0.4103.116 Safari/537.36"
    }
    payload = {"gen_date": date}
    r = requests.post(url=url, data=payload, headers=headers, timeout=15)
    r.raise_for_status()
    data_json = r.json()
    temp_df = pd.DataFrame(data_json["data"])
    symbol_list = list(
        set([item.upper() for item in temp_df["varietyOrder"].tolist() if item != ""])
    )
    temp_df.rename(
        columns={
            "varietyOrder": "symbol",
            "variety": "品种",
            "whAbbr": "仓库/分库",
            "lastWbillQty": "昨日仓单量",
            "wbillQty": "今日仓单量",
            "diff": "增减",
        },
        inplace=True,
    )
    temp_df = temp_df[
        [
            "symbol",
            "whType",
            "品种",
            "仓库/分库",
            "昨日仓单量",
            "今日仓单量",
            "增减",
        ]
    ]
    temp_df["whType"] = pd.to_numeric(temp_df["whType"], errors="coerce")
    temp_df.dropna(
        subset=["whType"], how="any", axis=0, ignore_index=True, inplace=True
    )
    big_dict = dict()
    for symbol in symbol_list:
        inner_temp_df = temp_df[temp_df["symbol"] == symbol.lower()].copy()
        inner_temp_df = inner_temp_df[
            [
                "品种",
                "仓库/分库",
                "昨日仓单量",
                "今日仓单量",
                "增减",
            ]
        ]
        inner_temp_df["昨日仓单量"] = pd.to_numeric(
            inner_temp_df["昨日仓单量"], errors="coerce"
        )
        inner_temp_df["今日仓单量"] = pd.to_numeric(
            inner_temp_df["今日仓单量"], errors="coerce"
        )
        inner_temp_df["增减"] = pd.to_numeric(inner_temp_df["增减"], errors="coerce")
        inner_temp_df.reset_index(inplace=True, drop=True)
        big_dict[symbol] = inner_temp_df
    return big_dict


if __name__ == "__main__":
    futures_warehouse_receipt_czce_df = futures_warehouse_receipt_czce(date="20251014")
    print(futures_warehouse_receipt_czce_df)

    futures_shfe_warehouse_receipt_df = futures_shfe_warehouse_receipt(date="20260924")
    print(futures_shfe_warehouse_receipt_df)

    futures_shfe_warehouse_receipt_df = futures_shfe_warehouse_receipt(date="20200702")
    print(futures_shfe_warehouse_receipt_df)

    futures_shfe_warehouse_receipt_df = futures_shfe_warehouse_receipt(date="20140516")
    print(futures_shfe_warehouse_receipt_df)

    futures_gfex_warehouse_receipt_df = futures_gfex_warehouse_receipt(date="20240122")
    print(futures_gfex_warehouse_receipt_df)

    futures_gfex_warehouse_receipt_df = futures_gfex_warehouse_receipt(date="20260226")
    print(futures_gfex_warehouse_receipt_df)

    futures_warehouse_receipt_dce_df = futures_warehouse_receipt_dce(date="20251014")
    print(futures_warehouse_receipt_dce_df)
